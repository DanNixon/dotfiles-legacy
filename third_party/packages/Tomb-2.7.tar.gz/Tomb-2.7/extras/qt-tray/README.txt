
Build with 'qmake' and then 'make'

Requires QT version 5.4 or above

